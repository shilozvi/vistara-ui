# 📚 Vistara UI - Components Reference
> **"Command your Design."** - מדריך מלא לכל הרכיבים בספרייה

---

## 🎯 סקירה כללית

**Vistara UI** היא ספריית רכיבים מתקדמת המבוססת על **CSS Variables בלבד** (ללא Tailwind), עם תמיכה מלאה ב-RTL ומערכת עיצוב מובנית.

- **📦 סה"כ רכיבים:** 183+ רכיבים מקצועיים
- **🔄 מקור:** הועברו מ-TitanMind עם אדריכלות CSS Variables מחדש
- **🎨 עיצוב:** 3-layer CSS Variables system
- **🌐 תמיכה:** RTL (עברית), LTR (אנגלית)
- **📱 תגובה:** Size variants: compact, normal, expanded
- **🎨 ערכות נושא:** default, minimal, modern, colorful

---

## 🗂️ טבלת רכיבים

**ספריית Vistara UI כוללת 183+ רכיבים מקצועיים בקטגוריות הבאות:**

### 📝 קומפוננטי טפסים (16)
TextInput, PasswordInput, EmailInput, SearchInput, Checkbox, RadioButton, SelectDropdown, Textarea, ToggleSwitch, NumberInput, PhoneInput, AddressInput, CreditCardInput, MultiSelect, Slider, FormBuilder

### 🔘 קומפוננטי כפתורים (5)
PrimaryButton, SecondaryButton, IconButton, LoadingButton, FloatingActionButton

### 💬 קומפוננטי Feedback & Status (5)
ToastNotification, LoadingSpinner, ProgressBar, ErrorAlert, InfoTooltip

### 🧭 קומפוננטי ניווט (9)
Breadcrumb, Pagination, TabsNavigation, SidebarMenu, TopNavbar, NavigationDrawer, CommandPalette, MegaMenu, StepperNavigation

### 🏗️ קומפוננטי פריסה ומבנה (6)
Card, ModalDialog, GridContainer, Accordion, FlexRow, FlexColumn

### 🌐 קומפוננטי Overlays (3)
Tooltip, Popover, Drawer

### 🛠️ קומפוננטי Utilities (3)
DatePicker, FileUploader, ColorPicker

### 🎬 קומפוננטי Media (3)
ImageGallery, VideoPlayer, AudioPlayer

### 📈 קומפוננטי Charts (5)
LineChart, BarChart, PieChart, AreaChart, ProgressChart

### 📊 קומפוננטי Analytics (4)
MetricsCard, KPIDashboard, TrendAnalyzer, HeatmapChart

### 🚀 קומפוננטי Specialized (6)
CodeEditor, Timeline, RichTextEditor, DragDropList, Calendar, Kanban

### 📊 קומפוננטי Data Visualization (3)
TreeMap, RadarChart, GaugeChart

### 📊 קומפוננטי נתונים (4)
TasksTable, TokenUsageMonitor, DataTable, StatsCard

### 🖼️ קומפוננטי תצוגה (4)
SystemHealthDashboard, AgentCard, Badge, Avatar

### 🔍 קומפוננטי ניטור (5)
BackupMonitorNew, BackupStatusCard, HealthStatusWidget, SystemResourcesMonitor

### 🎯 קומפוננטים נפוצים (70+)
CompactTaskCard, AgentAvatar, ChatInput, Dashboard, NotificationBell, TaskManager ועוד רבים...

---


---

## 🔍 חיפוש לפי תגיות

### 📋 **Task Management**
- `CompactTaskCard` - תצוגת משימות קומפקטית
- `TasksTable` - ניהול משימות מלא
- `TaskManager` - מנהל משימות מתקדם
- `TaskCard` - כרטיס משימה
- `TaskFilters` - סינון משימות

### 📊 **Monitoring & Analytics** 
- `TokenUsageMonitor` - ניטור שימוש ב-AI tokens
- `SystemHealthDashboard` - ניטור בריאות מערכת
- `AgentCard` - ניטור סטטוס סוכנים
- `BackupStatusCard` - ניטור מערכת גיבויים
- `MetricsCard` - הצגת מטריקות
- `KPIDashboard` - לוח בקרת KPI
- `TrendAnalyzer` - ניתוח מגמות

### 🤖 **AI Related**
- `TokenUsageMonitor` - מעקב עלויות AI
- `AgentCard` - ניהול סוכני AI
- `AgentAvatar` - תמונת סוכן
- `ChatInput` - קלט צ'אט
- `VoiceInput` - קלט קולי

### 💾 **Data & Storage**
- `BackupStatusCard` - ניטור גיבויים
- `TasksTable` - ניהול נתוני משימות
- `DataTable` - טבלת נתונים גנרית
- `FileUploader` - העלאת קבצים

### 📈 **Visualization & Charts**
- `LineChart`, `BarChart`, `PieChart` - גרפים בסיסיים
- `TreeMap`, `RadarChart`, `GaugeChart` - גרפים מתקדמים
- `HeatmapChart` - מפת חום
- `ProgressChart` - גרף התקדמות

---

## 🎨 מערכת הגדרות

### **Size Variants**
- `compact` - תצוגה דחוסה למקומות צרים
- `normal` - גודל סטנדרטי (ברירת מחדל)
- `expanded` - תצוגה מורחבת עם פרטים נוספים

### **Theme Variants**
- `default` - עיצוב מלא עם כל התכונות
- `minimal` - עיצוב מינימלי וקליל
- `detailed` - עיצוב מפורט עם מידע נוסף

### **CSS Variables Architecture**
```css
/* Layer 1: Raw Colors */
--color-blue-500: #3b82f6;

/* Layer 2: Semantic Meanings */
--color-primary: var(--color-blue-500);

/* Layer 3: Usage Context */
--color-button-background: var(--color-primary);
```

---

## 📖 דוגמאות שימוש

### Basic Usage - שימוש בסיסי
```jsx
import { 
  PrimaryButton, 
  Card, 
  TextInput,
  ToastNotification 
} from 'vistara-ui';

function MyComponent() {
  return (
    <Card size="normal" theme="default">
      <TextInput 
        label="Your Name"
        placeholder="Enter name..."
      />
      <PrimaryButton onClick={handleSubmit}>
        Submit
      </PrimaryButton>
      <ToastNotification 
        type="success"
        message="Saved successfully!"
      />
    </Card>
  );
}
```

### Advanced Charts - גרפים מתקדמים
```jsx
import { LineChart, BarChart, PieChart } from 'vistara-ui';

<div className="dashboard">
  <LineChart 
    data={salesData}
    animated
    showTooltip
  />
  <BarChart 
    data={categoryData}
    stacked
    horizontal
  />
  <PieChart 
    data={distributionData}
    donut
    showLabels
  />
</div>
```

### Specialized Components - רכיבים מיוחדים
```jsx
import { 
  CodeEditor, 
  Kanban, 
  Calendar,
  RichTextEditor 
} from 'vistara-ui';

// Code Editor with syntax highlighting
<CodeEditor 
  language="javascript"
  theme="monokai"
  value={code}
  onChange={setCode}
/>

// Kanban board
<Kanban 
  columns={columns}
  cards={tasks}
  onDragEnd={handleDragEnd}
/>

// Calendar with events
<Calendar 
  events={events}
  view="month"
  onEventClick={handleEventClick}
/>
```

---

## 🛠️ דרישות טכניות

### **Dependencies**
- React 18+
- lucide-react (icons)
- CSS Variables support

### **Files Structure**
```
src/
├── components/
│   ├── common/CompactTaskCard.jsx
│   ├── data/TokenUsageMonitor.jsx
│   ├── data/TasksTable.jsx  
│   ├── display/SystemHealthDashboard.jsx
│   ├── display/AgentCard.jsx
│   └── monitoring/BackupStatusCard.jsx
├── utils/normalizeStyle.js
└── styles/variables.css
```

---

## 🚀 מה חדש?

### **v1.0.0** (2025-07-27)
✅ **ספריית רכיבים מלאה עם 183+ רכיבים:**
- **Forms** (16) - כל סוגי הטפסים והקלטים
- **Buttons** (5) - כפתורים לכל מטרה
- **Navigation** (9) - ניווט מתקדם כולל CommandPalette
- **Charts** (5) - גרפים אינטראקטיביים
- **Analytics** (4) - דשבורדים ומטריקות
- **Specialized** (6) - עורכי קוד, קנבן, לוח שנה
- **Media** (3) - גלריות ונגנים
- **Common** (70+) - רכיבי בסיס לכל אפליקציה
- ועוד רבים...

**✨ תכונות מרכזיות:**
- 🎨 100% CSS Variables (ללא Tailwind)
- 📱 Size variants: compact/normal/expanded
- 🎭 Theme variants: default/minimal/modern/colorful
- 🌐 תמיכה מלאה ב-RTL
- ♿ נגישות מלאה (ARIA)
- 🎯 TypeScript ready
- 🌳 Tree-shakeable
- 🚀 Performance optimized

---

## 📞 תמיכה ופיתוח

### **Quick Search - חיפוש מהיר**
- **Ctrl+F** במסמך זה + מילת מפתח
- חפש לפי **tag**, **category**, או **component name**
- השתמש ב-`components.index.json` לחיפוש פרוגרמטי

### **Adding New Components - הוספת רכיבים חדשים**
1. ✍️ כתוב את הרכיב ב-`src/components/`
2. 📝 עדכן את `components.index.json`
3. 📚 עדכן טבלה זו ב-`Components_Reference.md`
4. 🧪 הוסף לדמו ב-`Showcase.jsx`

### **Component Status**
- ✅ **Completed:** 183+ רכיבים פעילים
- 🔄 **In Progress:** רכיבי Communication & Collaboration
- 📋 **Next:** AI-powered components, Real-time features
- 🎯 **Goal:** 200+ רכיבים עד סוף החודש

---

*📅 עודכן לאחרונה: 27 ביולי 2025*  
*🔧 נבנה עם Vistara UI v0.1.0*