// 🔒 Vistara UI - COMPLETE TitanMind Export
// ALL COMPONENTS FROM TITANMIND - 100% DEPENDENCY!

// === 📊 Data Components ===
export { default as TasksTable } from './src/components/data/TasksTable.jsx';
export { default as SystemHealthDashboard } from './src/components/SystemHealthDashboard.jsx';

// === 🎛️ Layout Components ===
export { default as Header } from '../TitanMind/dashboard/frontend/src/components/Layout/Header.jsx';
export { default as Layout } from '../TitanMind/dashboard/frontend/src/components/Layout/Layout.jsx';
export { default as Navigation } from '../TitanMind/dashboard/frontend/src/components/Layout/Navigation.jsx';

// === 🔧 Common Components ===
export { default as CompactTaskCard } from '../TitanMind/dashboard/frontend/src/components/common/CompactTaskCard/CompactTaskCard.jsx';
export { default as LazyImage } from '../TitanMind/dashboard/frontend/src/components/common/LazyImage/LazyImage.jsx';
export { default as MessageTimer } from '../TitanMind/dashboard/frontend/src/components/common/MessageTimer/MessageTimer.jsx';
export { default as NotificationBell } from '../TitanMind/dashboard/frontend/src/components/common/NotificationBell/NotificationBell.jsx';
export { default as ThemeButton } from '../TitanMind/dashboard/frontend/src/components/common/ThemeButton/ThemeButton.jsx';
export { default as ThemeToggle } from '../TitanMind/dashboard/frontend/src/components/common/ThemeToggle/ThemeToggle.jsx';

// === 🤖 Agent Components ===
export { default as AgentStatusMonitor } from '../TitanMind/dashboard/frontend/src/components/features/agents/AgentStatusMonitor/AgentStatusMonitor.jsx';
export { default as AgentTriggerPanel } from '../TitanMind/dashboard/frontend/src/components/features/agents/AgentTriggerPanel/AgentTriggerPanel.jsx';

// === 💬 Chat Components ===
export { default as AgentAvatar } from '../TitanMind/dashboard/frontend/src/components/features/chat/ChatPanel/AgentAvatar.jsx';
export { default as ChatInput } from '../TitanMind/dashboard/frontend/src/components/features/chat/ChatPanel/ChatInput.jsx';
export { default as ChatPanel } from '../TitanMind/dashboard/frontend/src/components/features/chat/ChatPanel/ChatPanel.jsx';
export { default as ChatWindow } from '../TitanMind/dashboard/frontend/src/components/features/chat/ChatPanel/ChatWindow.jsx';
export { default as MessageBubble } from '../TitanMind/dashboard/frontend/src/components/features/chat/ChatPanel/MessageBubble.jsx';
export { default as Phi3ManagerChat } from '../TitanMind/dashboard/frontend/src/components/features/chat/ChatPanel/Phi3ManagerChat.jsx';
export { default as TypingIndicator } from '../TitanMind/dashboard/frontend/src/components/features/chat/ChatPanel/TypingIndicator.jsx';

// === 📊 Monitoring Components ===
export { default as BackupMonitor } from '../TitanMind/dashboard/frontend/src/components/features/monitoring/BackupMonitor.jsx';
export { default as BackupMonitorNew } from '../TitanMind/dashboard/frontend/src/components/features/monitoring/BackupMonitor.new.jsx';
export { default as HealthStatusWidget } from '../TitanMind/dashboard/frontend/src/components/features/monitoring/HealthStatusWidget.jsx';
export { default as SystemResourcesMonitor } from '../TitanMind/dashboard/frontend/src/components/features/monitoring/SystemResourcesMonitor.jsx';
// TEMPORARILY EXCLUDED: ProcessMonitor has syntax error
// export { default as ProcessMonitor } from '../TitanMind/dashboard/frontend/src/components/features/monitoring/ProcessMonitor/ProcessMonitor.jsx';
export { default as NotificationToast } from '../TitanMind/dashboard/frontend/src/components/features/monitoring/ProcessMonitor/NotificationToast.jsx';
export { default as SystemLogs } from '../TitanMind/dashboard/frontend/src/components/features/monitoring/ProcessMonitor/SystemLogs.jsx';
export { default as TerminalPoolStatus } from '../TitanMind/dashboard/frontend/src/components/features/monitoring/TerminalPoolStatus/TerminalPoolStatus.jsx';

// === ✅ Task Components ===
export { default as ChatTasksMonitor } from '../TitanMind/dashboard/frontend/src/components/features/tasks/ChatTasksMonitor/ChatTasksMonitor.jsx';
export { default as TaskBotPanel } from '../TitanMind/dashboard/frontend/src/components/features/tasks/TaskBotPanel.jsx';
export { default as TaskDetailModal } from '../TitanMind/dashboard/frontend/src/components/features/tasks/TaskDetailModal/TaskDetailModal.jsx';
export { default as TaskCard } from '../TitanMind/dashboard/frontend/src/components/features/tasks/TaskManager/TaskCard.jsx';
export { default as TaskFilters } from '../TitanMind/dashboard/frontend/src/components/features/tasks/TaskManager/TaskFilters.jsx';
export { default as TaskForm } from '../TitanMind/dashboard/frontend/src/components/features/tasks/TaskManager/TaskForm.jsx';
export { default as TaskFormUpdated } from '../TitanMind/dashboard/frontend/src/components/features/tasks/TaskManager/TaskForm.updated.jsx';
export { default as TaskManager } from '../TitanMind/dashboard/frontend/src/components/features/tasks/TaskManager/TaskManager.jsx';
export { default as TaskSummaryCompact } from '../TitanMind/dashboard/frontend/src/components/features/tasks/TaskSummaryCompact/TaskSummaryCompact.jsx';
export { default as TasksCSVTable } from '../TitanMind/dashboard/frontend/src/components/features/tasks/TasksCSVTable/TasksCSVTable.jsx';

// === 🎤 Voice Components ===
export { default as VoiceInput } from '../TitanMind/dashboard/frontend/src/components/features/voice/VoiceInput.jsx';
export { default as VoiceSettings } from '../TitanMind/dashboard/frontend/src/components/features/voice/VoiceSettings.jsx';
export { default as VoiceWave } from '../TitanMind/dashboard/frontend/src/components/features/voice/VoiceWave/VoiceWave.jsx';

// === 📄 Page Components ===
export { default as BulkTaskUpload } from '../TitanMind/dashboard/frontend/src/components/pages/CreateTaskPage/BulkTaskUpload.jsx';
export { default as CreateTaskPage } from '../TitanMind/dashboard/frontend/src/components/pages/CreateTaskPage/CreateTaskPage.jsx';
export { default as AgentStatus } from '../TitanMind/dashboard/frontend/src/components/pages/Dashboard/AgentStatus.jsx';
export { default as Dashboard } from '../TitanMind/dashboard/frontend/src/components/pages/Dashboard/Dashboard.jsx';
export { default as DashboardTaskSection } from '../TitanMind/dashboard/frontend/src/components/pages/Dashboard/DashboardTaskSection.jsx';
export { default as QuickActions } from '../TitanMind/dashboard/frontend/src/components/pages/Dashboard/QuickActions.jsx';
export { default as RecentActivity } from '../TitanMind/dashboard/frontend/src/components/pages/Dashboard/RecentActivity.jsx';
export { default as SystemStats } from '../TitanMind/dashboard/frontend/src/components/pages/Dashboard/SystemStats.jsx';
export { default as TokenAnalytics } from '../TitanMind/dashboard/frontend/src/components/pages/Dashboard/TokenAnalytics.jsx';
export { default as DashboardMainView } from '../TitanMind/dashboard/frontend/src/components/pages/DashboardMainView/DashboardMainView.jsx';
export { default as MainView } from '../TitanMind/dashboard/frontend/src/components/pages/MainView/MainView.jsx';
export { default as MonitorPage } from '../TitanMind/dashboard/frontend/src/components/pages/MonitorPage/MonitorPage.jsx';
export { default as SimpleMainView } from '../TitanMind/dashboard/frontend/src/components/pages/SimpleMainView/SimpleMainView.jsx';
export { default as AsyncChatButton } from '../TitanMind/dashboard/frontend/src/components/pages/SimpleMainView/AsyncChatButton.jsx';
export { default as StreamingButton } from '../TitanMind/dashboard/frontend/src/components/pages/SimpleMainView/StreamingButton.jsx';
export { default as StreamingMessage } from '../TitanMind/dashboard/frontend/src/components/pages/SimpleMainView/StreamingMessage.jsx';
export { default as ThemeDemo } from '../TitanMind/dashboard/frontend/src/components/pages/ThemeDemo/ThemeDemo.jsx';
export { default as VoiceTestPage } from '../TitanMind/dashboard/frontend/src/components/pages/VoiceTestPage/VoiceTestPage.jsx';

// === ⚙️ Settings Components ===
export { default as DataSettings } from '../TitanMind/dashboard/frontend/src/components/settings/DataSettings/DataSettings.jsx';
export { default as GPTSettings } from '../TitanMind/dashboard/frontend/src/components/settings/GPTSettings/GPTSettings.jsx';
export { default as ManagementPanel } from '../TitanMind/dashboard/frontend/src/components/settings/Management/ManagementPanel.jsx';

// === 🔗 Shared Components ===
export { default as BaseMonitor } from '../TitanMind/dashboard/frontend/src/components/shared/BaseMonitor.jsx';
export { default as TokenUsageWidget } from '../TitanMind/dashboard/frontend/src/components/shared/TokenUsageWidget.jsx';

// === 🛠️ Utility Components ===
export { default as TailwindTest } from '../TitanMind/dashboard/frontend/src/components/utils/TailwindTest.jsx';
export { default as TokenUsageMonitor } from '../TitanMind/dashboard/frontend/src/components/utils/ui/TokenUsageMonitor.jsx';

// === 🛠️ Utils ===
export { normalizeStyle, withNormalizedStyles } from './src/utils/normalizeStyle.js';

// CSS styles
export const stylesPath = './dist/styles.css';