// 🎯 Vistara UI - MINIMAL Export for TitanMind Integration
// Only essential working components

// ONLY TasksTable - the component TitanMind actually needs
export { default as TasksTable } from './src/components/data/TasksTable.jsx';

// CSS styles
export const stylesPath = './dist/styles.css';