# 🚀 פריסה ותפעול - Vistara UI

> **סטטוס:** Active  
> **עודכן לאחרונה:** 2025-07-27  
> **רמת קושי:** Intermediate  
> **זמן קריאה:** כ־5 דקות  
> **שייך לקטגוריה:** 04_deployment  

---

## מדריכי פריסה זמינים:
- [build_guide.md](./build_guide.md) - בניית הפרויקט
- [npm_publishing.md](./npm_publishing.md) - פרסום כ-NPM Package
- [cdn_deployment.md](./cdn_deployment.md) - פריסה ל-CDN
- [storybook_deployment.md](./storybook_deployment.md) - פריסת Storybook

---

*מדריך ימולא בהמשך*