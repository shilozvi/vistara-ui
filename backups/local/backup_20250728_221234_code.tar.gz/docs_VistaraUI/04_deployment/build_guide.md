# 🏗️ מדריך Build - Vistara UI

> **סטטוס:** Active  
> **עודכן לאחרונה:** 2025-07-27  
> **רמת קושי:** Beginner  
> **זמן קריאה:** כ־6 דקות  
> **שייך לקטגוריה:** 04_deployment  

---

## מדריך זה יכלול:
- npm run build
- אופטימיזציה לייצור
- Tree Shaking
- CSS Optimization
- בדיקת גודל Bundle

---

*מדריך ימולא בהמשך*