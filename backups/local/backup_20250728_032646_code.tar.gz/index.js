// 🎯 Vistara UI - Main Export File
// "Command your Design."

// Common Components
export { default as CompactTaskCard } from './src/components/common/CompactTaskCard.jsx';
export { default as ThemeToggle } from './src/components/common/ThemeToggle.jsx';
export { default as NotificationBell } from './src/components/common/NotificationBell.jsx';
export { default as VoiceWave } from './src/components/common/VoiceWave.jsx';
// export { default as LoadingSpinner } from './src/components/feedback/LoadingSpinner.jsx'; // JSX syntax issues

// Data Components  
export { default as TokenUsageMonitor } from './src/components/data/TokenUsageMonitor.jsx';
export { default as TasksTable } from './src/components/data/TasksTable.jsx';

// Display Components
export { default as SystemHealthDashboard } from './src/components/display/SystemHealthDashboard.jsx';
export { default as AgentCard } from './src/components/display/AgentCard.jsx';

// Button Components
export { default as PrimaryButton } from './src/components/buttons/PrimaryButton.jsx';
export { default as SecondaryButton } from './src/components/buttons/SecondaryButton.jsx';
export { default as IconButton } from './src/components/buttons/IconButton.jsx';

// Monitoring Components
export { default as BackupStatusCard } from './src/components/monitoring/BackupStatusCard.jsx';

// Chat Components
export { default as ChatInput } from './src/components/common/ChatInput.jsx';
export { default as TypingIndicator } from './src/components/common/TypingIndicator.jsx';
export { default as VoiceInput } from './src/components/common/VoiceInput.jsx';

// Dashboard Components
export { default as SystemStats } from './src/components/common/SystemStats.jsx';
export { default as RecentActivity } from './src/components/common/RecentActivity.jsx';
export { default as QuickActions } from './src/components/common/QuickActions.jsx';
export { default as TaskSummaryCompact } from './src/components/common/TaskSummaryCompact.jsx';
export { default as Card } from './src/components/layout/Card.jsx';
export { default as StatsCard } from './src/components/data/StatsCard.jsx';
export { default as Badge } from './src/components/display/Badge.jsx';

// Task Components
export { default as TaskCard } from './src/components/common/TaskCard.jsx';
export { default as TaskFilters } from './src/components/common/TaskFilters.jsx';

// Utils - commented out for now due to JSX syntax issues
// export { normalizeStyle, withNormalizedStyles } from './src/utils/normalizeStyle.js';

// Explorer - commented out due to JSX syntax parsing issues
// export { default as ComponentsExplorer } from './src/components/ComponentsExplorer.jsx';

// Styles - יצוא נתיב לקובץ CSS
export const vistaraStylesPath = '/src/styles/tokens.css';