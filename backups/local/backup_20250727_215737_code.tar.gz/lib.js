// 🎯 Vistara UI - Library Export File
// "Command your Design."
// רק הרכיבים הציבוריים והמוכנים

// === קומפוננטי נתונים ===
export { default as TasksTable } from './src/components/data/TasksTable.jsx';
export { default as TokenUsageMonitor } from './src/components/data/TokenUsageMonitor.jsx';

// === קומפוננטי תצוגה ===
export { default as SystemHealthDashboard } from './src/components/display/SystemHealthDashboard.jsx';
export { default as AgentCard } from './src/components/display/AgentCard.jsx';

// === קומפוננטי ניטור ===
export { default as BackupStatusCard } from './src/components/monitoring/BackupStatusCard.jsx';

// === קומפוננטים נפוצים ===
export { default as CompactTaskCard } from './src/components/common/CompactTaskCard.jsx';

// === כלי עזר ===
export { normalizeStyle, withNormalizedStyles } from './src/utils/normalizeStyle.js';

// === סטיילים ===
// הצבעה לקובץ הסטיילים - יש לייבא בנפרד
export const stylesPath = './dist/styles.css';